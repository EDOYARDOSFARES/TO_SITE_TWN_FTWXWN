package com.athletico.eshop.tests;

import com.athletico.eshop.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mindrot.jbcrypt.BCrypt;
import org.mockito.MockedStatic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * We intentionally do NOT mock BCrypt itself - it's the security-critical part
 * of this class, so tests use a real bcrypt hash and real checkpw() calls to
 * make sure the actual hashing/verification logic is exercised.
 */
class UserDAOTest {

    private UserDAO userDAO;
    private Connection mockConnection;
    private PreparedStatement mockStatement;
    private ResultSet mockResultSet;

    private static final String REAL_PASSWORD = "password123";
    private static final String REAL_HASH = BCrypt.hashpw(REAL_PASSWORD, BCrypt.gensalt());

    @BeforeEach
    void setUp() {
        userDAO = new UserDAO();
        mockConnection = mock(Connection.class);
        mockStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
    }

    @Test
    void authenticate_correctCredentials_returnsUser() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getString("password_hash")).thenReturn(REAL_HASH);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("username")).thenReturn("george");
        when(mockResultSet.getString("role")).thenReturn("customer");

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            User result = userDAO.authenticate("george", REAL_PASSWORD);

            assertNotNull(result);
            assertEquals(1, result.getId());
            assertEquals("george", result.getUsername());
            assertEquals("customer", result.getRole());
        }
    }

    @Test
    void authenticate_wrongPassword_returnsNull() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getString("password_hash")).thenReturn(REAL_HASH);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            User result = userDAO.authenticate("george", "wrongPassword");

            assertNull(result);
        }
    }

    @Test
    void authenticate_unknownUsername_returnsNull() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(false); // no row found

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            User result = userDAO.authenticate("nobody", "whatever");

            assertNull(result);
        }
    }

    @Test
    void authenticate_sqlException_returnsNullInsteadOfThrowing() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("DB is down"));

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            User result = userDAO.authenticate("george", REAL_PASSWORD);

            assertNull(result);
        }
    }

    @Test
    void createUser_successfulInsert_returnsTrue() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(1);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = userDAO.createUser("newuser", "somePassword", "customer");

            assertTrue(result);
            verify(mockStatement).setString(1, "newuser");
            verify(mockStatement).setString(3, "customer");
        }
    }

    @Test
    void createUser_noRowsAffected_returnsFalse() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(0);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = userDAO.createUser("newuser", "somePassword", "customer");

            assertFalse(result);
        }
    }

    @Test
    void createUser_sqlException_returnsFalse() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("duplicate username"));

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = userDAO.createUser("newuser", "somePassword", "customer");

            assertFalse(result);
        }
    }
}
