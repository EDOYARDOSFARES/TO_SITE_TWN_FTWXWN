package com.athletico.eshop.tests;

import com.athletico.eshop.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

class SessionTest {

    private Session session;

    @BeforeEach
    void resetSingleton() throws Exception {
        Field instanceField = Session.class.getDeclaredField("instance");
        instanceField.setAccessible(true);
        instanceField.set(null, null);

        session = Session.getInstance();
    }

    @Test
    void getInstance_alwaysReturnsSameInstance() {
        assertSame(session, Session.getInstance());
    }

    @Test
    void newSession_isNotLoggedIn() {
        assertFalse(session.isLoggedIn());
        assertNull(session.getUsername());
        assertNull(session.getRole());
    }

    @Test
    void login_setsUserIdUsernameAndRole() {
        session.login(7, "george", "customer");

        assertEquals(7, session.getUserId());
        assertEquals("george", session.getUsername());
        assertEquals("customer", session.getRole());
        assertTrue(session.isLoggedIn());
    }

    @Test
    void isAdmin_trueForAdminRole() {
        session.login(1, "boss", "admin");
        assertTrue(session.isAdmin());
    }

    @Test
    void isAdmin_isCaseInsensitive() {
        session.login(1, "boss", "ADMIN");
        assertTrue(session.isAdmin());
    }

    @Test
    void isAdmin_falseForCustomerRole() {
        session.login(2, "customer1", "customer");
        assertFalse(session.isAdmin());
    }

    @Test
    void logout_clearsAllSessionData() {
        session.login(3, "maria", "customer");
        session.logout();

        assertFalse(session.isLoggedIn());
        assertNull(session.getUsername());
        assertNull(session.getRole());
        assertEquals(0, session.getUserId());
    }
}
