package com.athletico.eshop.tests;

import com.athletico.eshop.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CartItemTest {

    private Product product;
    private CartItem cartItem;

    @BeforeEach
    void setUp() {
        product = new Product(1, "Football", 20.0, 15, "football.png");
        cartItem = new CartItem(product, 2);
    }

    @Test
    void constructor_setsProductAndQuantity() {
        assertEquals(product, cartItem.getProduct());
        assertEquals(2, cartItem.getQuantity());
    }

    @Test
    void setQuantity_updatesQuantity() {
        cartItem.setQuantity(5);
        assertEquals(5, cartItem.getQuantity());
    }

    @Test
    void quantityProperty_reflectsCurrentQuantity() {
        assertEquals(2, cartItem.quantityProperty().get());
        cartItem.setQuantity(7);
        assertEquals(7, cartItem.quantityProperty().get());
    }

    @Test
    void getTotal_multipliesPriceByQuantity() {
        assertEquals(40.0, cartItem.getTotal(), 0.0001);
    }

    @Test
    void getTotal_afterQuantityChange_recalculates() {
        cartItem.setQuantity(4);
        assertEquals(80.0, cartItem.getTotal(), 0.0001);
    }

    @Test
    void productNameProperty_matchesProductName() {
        assertEquals("Football", cartItem.productNameProperty().get());
    }

    @Test
    void priceProperty_matchesProductPrice() {
        assertEquals(20.0, cartItem.priceProperty().get(), 0.0001);
    }
}
