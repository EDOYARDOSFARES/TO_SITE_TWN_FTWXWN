package com.athletico.eshop.tests;

import com.athletico.eshop.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    private Product product;

    @BeforeEach
    void setUp() {
        product = new Product(1, "Running Shoes", 49.99, 10, "shoes.png");
    }

    @Test
    void constructorAndGetters_returnCorrectValues() {
        assertEquals(1, product.getId());
        assertEquals("Running Shoes", product.getName());
        assertEquals(49.99, product.getPrice());
        assertEquals(10, product.getStock());
        assertEquals("shoes.png", product.getImagePath());
    }

    @Test
    void setPrice_withValidValue_updatesPrice() {
        product.setPrice(59.99);
        assertEquals(59.99, product.getPrice());
    }

    @Test
    void setPrice_withZero_isAccepted() {
        product.setPrice(0);
        assertEquals(0, product.getPrice());
    }

    @Test
    void setPrice_withNegativeValue_isRejectedAndKeepsOldPrice() {
        product.setPrice(-10.0);
        assertEquals(49.99, product.getPrice(), "Negative price must not overwrite the existing price");
    }

    @Test
    void setStock_withValidValue_updatesStock() {
        product.setStock(25);
        assertEquals(25, product.getStock());
    }

    @Test
    void setStock_withNegativeValue_isRejectedAndKeepsOldStock() {
        product.setStock(-5);
        assertEquals(10, product.getStock(), "Negative stock must not overwrite the existing stock");
    }

    @Test
    void setName_updatesName() {
        product.setName("Trail Shoes");
        assertEquals("Trail Shoes", product.getName());
    }

    @Test
    void setImagePath_updatesImagePath() {
        product.setImagePath("new_image.png");
        assertEquals("new_image.png", product.getImagePath());
    }

    @Test
    void updateDetails_withValidValues_updatesAllFields() {
        product.updateDetails("New Name", 99.99, 5);
        assertEquals("New Name", product.getName());
        assertEquals(99.99, product.getPrice());
        assertEquals(5, product.getStock());
    }

    @Test
    void updateDetails_withNegativePriceAndStock_keepsOriginalPriceAndStockButUpdatesName() {
        product.updateDetails("New Name", -1.0, -1);
        assertEquals("New Name", product.getName(), "Name should still update");
        assertEquals(49.99, product.getPrice(), "Price should be unchanged since negative was rejected");
        assertEquals(10, product.getStock(), "Stock should be unchanged since negative was rejected");
    }

    @Test
    void toString_containsNameAndPrice() {
        String result = product.toString();
        assertTrue(result.contains("Running Shoes"));
        assertTrue(result.contains("49.99"));
    }
}
