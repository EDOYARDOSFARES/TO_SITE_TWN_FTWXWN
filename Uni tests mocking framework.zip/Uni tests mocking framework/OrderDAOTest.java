package com.athletico.eshop.tests;

import com.athletico.eshop.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class OrderDAOTest {

    private OrderDAO orderDAO;
    private Connection mockConnection;

    private PreparedStatement mockOrderStmt;
    private PreparedStatement mockItemStmt;
    private PreparedStatement mockStockStmt;
    private ResultSet mockGeneratedKeys;

    private Product product;
    private CartItem cartItem;

    @BeforeEach
    void setUp() throws SQLException {
        orderDAO = new OrderDAO();
        mockConnection = mock(Connection.class);

        mockOrderStmt = mock(PreparedStatement.class);
        mockItemStmt = mock(PreparedStatement.class);
        mockStockStmt = mock(PreparedStatement.class);
        mockGeneratedKeys = mock(ResultSet.class);

        // Route each SQL string to the matching mocked PreparedStatement,
        // mirroring the three different statements OrderDAO prepares.
        when(mockConnection.prepareStatement(startsWith("INSERT INTO orders"), eq(Statement.RETURN_GENERATED_KEYS)))
                .thenReturn(mockOrderStmt);
        when(mockConnection.prepareStatement(startsWith("INSERT INTO order_items")))
                .thenReturn(mockItemStmt);
        when(mockConnection.prepareStatement(startsWith("UPDATE products SET stock")))
                .thenReturn(mockStockStmt);

        when(mockOrderStmt.getGeneratedKeys()).thenReturn(mockGeneratedKeys);
        when(mockGeneratedKeys.next()).thenReturn(true);
        when(mockGeneratedKeys.getInt(1)).thenReturn(100); // generated order id

        product = new Product(1, "Yoga Mat", 25.0, 10, "mat.png");
        cartItem = new CartItem(product, 2);
    }

    @Test
    void createOrder_sufficientStock_commitsAndReturnsTrue() throws SQLException {
        when(mockStockStmt.executeUpdate()).thenReturn(1); // stock update succeeded

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = orderDAO.createOrder(1, List.of(cartItem));

            assertTrue(result);
            verify(mockConnection).commit();
            verify(mockConnection, never()).rollback();
            verify(mockItemStmt).setInt(1, 100); // order id used in order_items row
            verify(mockItemStmt).setInt(2, 1);   // product id
            verify(mockItemStmt).setInt(3, 2);   // quantity
        }
    }

    @Test
    void createOrder_insufficientStock_rollsBackAndReturnsFalse() throws SQLException {
        when(mockStockStmt.executeUpdate()).thenReturn(0); // "stock >= ?" condition failed

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = orderDAO.createOrder(1, List.of(cartItem));

            assertFalse(result);
            verify(mockConnection).rollback();
            verify(mockConnection, never()).commit();
        }
    }

    @Test
    void createOrder_generatedKeyMissing_rollsBackAndReturnsFalse() throws SQLException {
        when(mockGeneratedKeys.next()).thenReturn(false); // no generated key returned

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = orderDAO.createOrder(1, List.of(cartItem));

            assertFalse(result);
            verify(mockConnection).rollback();
        }
    }

    @Test
    void createOrder_sqlExceptionOnConnection_rollsBackAndReturnsFalse() throws SQLException {
        when(mockConnection.prepareStatement(startsWith("INSERT INTO orders"), anyInt()))
                .thenThrow(new SQLException("DB unreachable"));

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = orderDAO.createOrder(1, List.of(cartItem));

            assertFalse(result);
            verify(mockConnection).rollback();
        }
    }

    @Test
    void createOrder_alwaysRestoresAutoCommitAndClosesConnection() throws SQLException {
        when(mockStockStmt.executeUpdate()).thenReturn(1);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            orderDAO.createOrder(1, List.of(cartItem));

            verify(mockConnection).setAutoCommit(false);
            verify(mockConnection).setAutoCommit(true);
            verify(mockConnection).close();
        }
    }

    @Test
    void createOrder_totalAmountMatchesSumOfCartItems() throws SQLException {
        when(mockStockStmt.executeUpdate()).thenReturn(1);
        Product secondProduct = new Product(2, "Water Bottle", 10.0, 20, "bottle.png");
        CartItem secondItem = new CartItem(secondProduct, 3);
        // total = (25.0 * 2) + (10.0 * 3) = 80.0

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = orderDAO.createOrder(1, List.of(cartItem, secondItem));

            assertTrue(result);
            verify(mockOrderStmt).setDouble(2, 80.0);
        }
    }
}
