package com.athletico.eshop.tests;

import com.athletico.eshop.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class ProductDAOTest {

    private ProductDAO productDAO;
    private Connection mockConnection;
    private PreparedStatement mockStatement;
    private ResultSet mockResultSet;

    @BeforeEach
    void setUp() {
        productDAO = new ProductDAO();
        mockConnection = mock(Connection.class);
        mockStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
    }

    @Test
    void getAllProducts_returnsMappedListFromResultSet() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeQuery()).thenReturn(mockResultSet);

        // two rows, then end of result set
        when(mockResultSet.next()).thenReturn(true, true, false);
        when(mockResultSet.getInt("id")).thenReturn(1, 2);
        when(mockResultSet.getString("name")).thenReturn("Football", "Basketball");
        when(mockResultSet.getDouble("price")).thenReturn(20.0, 30.0);
        when(mockResultSet.getInt("stock")).thenReturn(15, 8);
        when(mockResultSet.getString("image_path")).thenReturn("football.png", "basketball.png");

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            List<Product> products = productDAO.getAllProducts();

            assertEquals(2, products.size());
            assertEquals("Football", products.get(0).getName());
            assertEquals(30.0, products.get(1).getPrice());
        }
    }

    @Test
    void getAllProducts_emptyTable_returnsEmptyList() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(false);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            List<Product> products = productDAO.getAllProducts();

            assertTrue(products.isEmpty());
        }
    }

    @Test
    void getAllProducts_sqlException_returnsEmptyListInsteadOfThrowing() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("connection lost"));

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            List<Product> products = productDAO.getAllProducts();

            assertNotNull(products);
            assertTrue(products.isEmpty());
        }
    }

    @Test
    void addProduct_successfulInsert_returnsTrue() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(1);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = productDAO.addProduct("Tennis Racket", 89.99, 5);

            assertTrue(result);
            verify(mockStatement).setString(1, "Tennis Racket");
            verify(mockStatement).setDouble(2, 89.99);
            verify(mockStatement).setInt(3, 5);
        }
    }

    @Test
    void addProduct_sqlException_returnsFalse() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("constraint violation"));

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = productDAO.addProduct("Tennis Racket", 89.99, 5);

            assertFalse(result);
        }
    }

    @Test
    void updateProduct_successfulUpdate_returnsTrue() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(1);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = productDAO.updateProduct(1, "Updated Name", 59.99, 10);

            assertTrue(result);
            verify(mockStatement).setInt(4, 1);
        }
    }

    @Test
    void updateProduct_noMatchingRow_returnsFalse() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(0);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = productDAO.updateProduct(999, "Name", 10.0, 1);

            assertFalse(result);
        }
    }

    @Test
    void deleteProduct_successfulDelete_returnsTrue() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(1);

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = productDAO.deleteProduct(1);

            assertTrue(result);
            verify(mockStatement).setInt(1, 1);
        }
    }

    @Test
    void deleteProduct_sqlException_returnsFalse() throws SQLException {
        when(mockConnection.prepareStatement(anyString()))
                .thenThrow(new SQLException("referenced by existing order"));

        try (MockedStatic<DatabaseConnection> mockedDb = mockStatic(DatabaseConnection.class)) {
            mockedDb.when(DatabaseConnection::getConnection).thenReturn(mockConnection);

            boolean result = productDAO.deleteProduct(1);

            assertFalse(result);
        }
    }
}
