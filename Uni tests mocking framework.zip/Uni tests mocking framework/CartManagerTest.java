package com.athletico.eshop.tests;

import com.athletico.eshop.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

class CartManagerTest {

    private CartManager cartManager;
    private Product product1;
    private Product product2;

    // CartManager is a singleton, so we reset its internal static instance
    // before every test to avoid state leaking between tests.
    @BeforeEach
    void resetSingletonAndInit() throws Exception {
        Field instanceField = CartManager.class.getDeclaredField("instance");
        instanceField.setAccessible(true);
        instanceField.set(null, null);

        cartManager = CartManager.getInstance();
        product1 = new Product(1, "Tennis Racket", 89.99, 5, "racket.png");
        product2 = new Product(2, "Tennis Balls", 4.99, 100, "balls.png");
    }

    @Test
    void getInstance_alwaysReturnsSameInstance() {
        assertSame(cartManager, CartManager.getInstance());
    }

    @Test
    void addProduct_newProduct_addsWithQuantityOne() {
        cartManager.addProduct(product1);

        assertEquals(1, cartManager.getItems().size());
        assertEquals(1, cartManager.getItems().get(0).getQuantity());
    }

    @Test
    void addProduct_existingProduct_incrementsQuantityInsteadOfDuplicating() {
        cartManager.addProduct(product1);
        cartManager.addProduct(product1);
        cartManager.addProduct(product1);

        assertEquals(1, cartManager.getItems().size(), "Should still be a single line item");
        assertEquals(3, cartManager.getItems().get(0).getQuantity());
    }

    @Test
    void addProduct_differentProducts_createsSeparateLines() {
        cartManager.addProduct(product1);
        cartManager.addProduct(product2);

        assertEquals(2, cartManager.getItems().size());
    }

    @Test
    void removeItem_removesTheGivenItem() {
        cartManager.addProduct(product1);
        cartManager.addProduct(product2);
        CartItem toRemove = cartManager.getItems().get(0);

        cartManager.removeItem(toRemove);

        assertEquals(1, cartManager.getItems().size());
        assertFalse(cartManager.getItems().contains(toRemove));
    }

    @Test
    void clear_emptiesTheCart() {
        cartManager.addProduct(product1);
        cartManager.addProduct(product2);

        cartManager.clear();

        assertTrue(cartManager.getItems().isEmpty());
    }

    @Test
    void getTotalItemCount_sumsQuantitiesAcrossLines() {
        cartManager.addProduct(product1);
        cartManager.addProduct(product1);
        cartManager.addProduct(product2);

        assertEquals(3, cartManager.getTotalItemCount());
    }

    @Test
    void getTotalItemCount_emptyCart_isZero() {
        assertEquals(0, cartManager.getTotalItemCount());
    }

    @Test
    void getTotalPrice_sumsLineTotals() {
        cartManager.addProduct(product1); // 89.99 * 1
        cartManager.addProduct(product2); // 4.99 * 1
        cartManager.addProduct(product2); // now qty 2 -> 4.99 * 2

        double expected = 89.99 + (4.99 * 2);
        assertEquals(expected, cartManager.getTotalPrice(), 0.0001);
    }

    @Test
    void getTotalPrice_emptyCart_isZero() {
        assertEquals(0.0, cartManager.getTotalPrice(), 0.0001);
    }
}
